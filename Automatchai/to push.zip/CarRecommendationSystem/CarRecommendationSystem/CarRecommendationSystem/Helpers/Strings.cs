﻿namespace CarRecommendationSystem.Helpers
{
    public static class Strings
    {
        public static string Budget = "Budget";
        public static string Horsepower = "Horsepower";
        public static string YouNeedToCheckOneOption = "You need to check ONE option.";
        public static string YouNeedToEnterIntegerValue = "You need to enter integer value.";
        public static string Oops = "Oops!";
    }
}
