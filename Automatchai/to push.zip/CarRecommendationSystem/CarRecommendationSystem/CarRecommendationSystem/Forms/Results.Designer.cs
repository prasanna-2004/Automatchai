﻿namespace CarRecommendationSystem.Forms
{
    partial class Results
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Results));
            this.lbl1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1stAlg = new System.Windows.Forms.PictureBox();
            this.label1stAlg = new System.Windows.Forms.Label();
            this.Alg1stCarName = new System.Windows.Forms.Label();
            this.Alg2ndCarName = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox2ndAlg = new System.Windows.Forms.PictureBox();
            this.Alg3rdCarName = new System.Windows.Forms.Label();
            this.label3rdAlg = new System.Windows.Forms.Label();
            this.pictureBox3rdAlg = new System.Windows.Forms.PictureBox();
            this.pictureBoxVerticalLine = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Alg1stPrice = new System.Windows.Forms.Label();
            this.Alg1stHorsepower = new System.Windows.Forms.Label();
            this.Alg1stLitres = new System.Windows.Forms.Label();
            this.Alg1stFuelType = new System.Windows.Forms.Label();
            this.Alg1stTransmission = new System.Windows.Forms.Label();
            this.Alg2ndTransmission = new System.Windows.Forms.Label();
            this.Alg2ndFuelType = new System.Windows.Forms.Label();
            this.Alg2ndLitres = new System.Windows.Forms.Label();
            this.Alg2ndHorsepower = new System.Windows.Forms.Label();
            this.Alg2ndPrice = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.Alg3rdTransmission = new System.Windows.Forms.Label();
            this.Alg3rdFuelType = new System.Windows.Forms.Label();
            this.Alg3rdLitres = new System.Windows.Forms.Label();
            this.Alg3rdHorsepower = new System.Windows.Forms.Label();
            this.Alg3rdPrice = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.ML1stTransmission = new System.Windows.Forms.Label();
            this.ML1stFuelType = new System.Windows.Forms.Label();
            this.ML1stLitres = new System.Windows.Forms.Label();
            this.ML1stHorsepower = new System.Windows.Forms.Label();
            this.ML1stCarPrice = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.ML1stCarName = new System.Windows.Forms.Label();
            this.ML1stNumber = new System.Windows.Forms.Label();
            this.pictureBox1stML = new System.Windows.Forms.PictureBox();
            this.ML2ndTransmission = new System.Windows.Forms.Label();
            this.ML2ndFuelType = new System.Windows.Forms.Label();
            this.ML2ndLitres = new System.Windows.Forms.Label();
            this.ML2ndHorsepower = new System.Windows.Forms.Label();
            this.ML2ndPrice = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.ML2ndCarName = new System.Windows.Forms.Label();
            this.ML2ndNumber = new System.Windows.Forms.Label();
            this.pictureBox2ndML = new System.Windows.Forms.PictureBox();
            this.ML3rdTransmission = new System.Windows.Forms.Label();
            this.ML3rdFuelType = new System.Windows.Forms.Label();
            this.ML3rdLitres = new System.Windows.Forms.Label();
            this.ML3rdHorsepower = new System.Windows.Forms.Label();
            this.ML3rdPrice = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.ML3rdCarName = new System.Windows.Forms.Label();
            this.ML3rdNumber = new System.Windows.Forms.Label();
            this.pictureBox3rdML = new System.Windows.Forms.PictureBox();
            this.lblFinishing = new System.Windows.Forms.Label();
            this.btnAgain = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1stAlg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2ndAlg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3rdAlg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxVerticalLine)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1stML)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2ndML)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3rdML)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(28, 5);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(850, 24);
            this.lbl1.TabIndex = 21;
            this.lbl1.Text = "All your preferences are collected and taken into account when recommending the b" +
    "est cars for you!";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(28, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(480, 24);
            this.label1.TabIndex = 22;
            this.label1.Text = "Score based algorithm has found the 3 best cars for you:";
            // 
            // pictureBox1stAlg
            // 
            this.pictureBox1stAlg.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1stAlg.Image")));
            this.pictureBox1stAlg.Location = new System.Drawing.Point(85, 170);
            this.pictureBox1stAlg.Name = "pictureBox1stAlg";
            this.pictureBox1stAlg.Size = new System.Drawing.Size(233, 111);
            this.pictureBox1stAlg.TabIndex = 23;
            this.pictureBox1stAlg.TabStop = false;
            // 
            // label1stAlg
            // 
            this.label1stAlg.AutoSize = true;
            this.label1stAlg.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1stAlg.Location = new System.Drawing.Point(27, 204);
            this.label1stAlg.Name = "label1stAlg";
            this.label1stAlg.Size = new System.Drawing.Size(32, 29);
            this.label1stAlg.TabIndex = 24;
            this.label1stAlg.Text = "1.";
            // 
            // Alg1stCarName
            // 
            this.Alg1stCarName.AutoSize = true;
            this.Alg1stCarName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alg1stCarName.Location = new System.Drawing.Point(81, 143);
            this.Alg1stCarName.Name = "Alg1stCarName";
            this.Alg1stCarName.Size = new System.Drawing.Size(120, 24);
            this.Alg1stCarName.TabIndex = 25;
            this.Alg1stCarName.Text = "1st Car name";
            // 
            // Alg2ndCarName
            // 
            this.Alg2ndCarName.AutoSize = true;
            this.Alg2ndCarName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alg2ndCarName.Location = new System.Drawing.Point(81, 326);
            this.Alg2ndCarName.Name = "Alg2ndCarName";
            this.Alg2ndCarName.Size = new System.Drawing.Size(129, 24);
            this.Alg2ndCarName.TabIndex = 28;
            this.Alg2ndCarName.Text = "2nd Car name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(27, 387);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 29);
            this.label3.TabIndex = 27;
            this.label3.Text = "2.";
            // 
            // pictureBox2ndAlg
            // 
            this.pictureBox2ndAlg.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2ndAlg.Image")));
            this.pictureBox2ndAlg.Location = new System.Drawing.Point(85, 353);
            this.pictureBox2ndAlg.Name = "pictureBox2ndAlg";
            this.pictureBox2ndAlg.Size = new System.Drawing.Size(233, 111);
            this.pictureBox2ndAlg.TabIndex = 26;
            this.pictureBox2ndAlg.TabStop = false;
            // 
            // Alg3rdCarName
            // 
            this.Alg3rdCarName.AutoSize = true;
            this.Alg3rdCarName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alg3rdCarName.Location = new System.Drawing.Point(81, 487);
            this.Alg3rdCarName.Name = "Alg3rdCarName";
            this.Alg3rdCarName.Size = new System.Drawing.Size(124, 24);
            this.Alg3rdCarName.TabIndex = 31;
            this.Alg3rdCarName.Text = "3rd Car name";
            // 
            // label3rdAlg
            // 
            this.label3rdAlg.AutoSize = true;
            this.label3rdAlg.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3rdAlg.Location = new System.Drawing.Point(27, 548);
            this.label3rdAlg.Name = "label3rdAlg";
            this.label3rdAlg.Size = new System.Drawing.Size(32, 29);
            this.label3rdAlg.TabIndex = 30;
            this.label3rdAlg.Text = "3.";
            // 
            // pictureBox3rdAlg
            // 
            this.pictureBox3rdAlg.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3rdAlg.Image")));
            this.pictureBox3rdAlg.Location = new System.Drawing.Point(85, 514);
            this.pictureBox3rdAlg.Name = "pictureBox3rdAlg";
            this.pictureBox3rdAlg.Size = new System.Drawing.Size(233, 111);
            this.pictureBox3rdAlg.TabIndex = 29;
            this.pictureBox3rdAlg.TabStop = false;
            // 
            // pictureBoxVerticalLine
            // 
            this.pictureBoxVerticalLine.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxVerticalLine.Image")));
            this.pictureBoxVerticalLine.Location = new System.Drawing.Point(680, 64);
            this.pictureBoxVerticalLine.Name = "pictureBoxVerticalLine";
            this.pictureBoxVerticalLine.Size = new System.Drawing.Size(10, 577);
            this.pictureBoxVerticalLine.TabIndex = 32;
            this.pictureBoxVerticalLine.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(324, 181);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 24);
            this.label2.TabIndex = 33;
            this.label2.Text = "Price:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(324, 205);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 24);
            this.label4.TabIndex = 34;
            this.label4.Text = "HP:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(324, 229);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 24);
            this.label5.TabIndex = 35;
            this.label5.Text = "Fuel type:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(445, 204);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(157, 24);
            this.label6.TabIndex = 36;
            this.label6.Text = "Litres per 100 km:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(324, 253);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(127, 24);
            this.label7.TabIndex = 37;
            this.label7.Text = "Transmission:";
            // 
            // Alg1stPrice
            // 
            this.Alg1stPrice.AutoSize = true;
            this.Alg1stPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alg1stPrice.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.Alg1stPrice.Location = new System.Drawing.Point(393, 181);
            this.Alg1stPrice.Name = "Alg1stPrice";
            this.Alg1stPrice.Size = new System.Drawing.Size(221, 24);
            this.Alg1stPrice.TabIndex = 38;
            this.Alg1stPrice.Text = "Here goes price in kunas";
            // 
            // Alg1stHorsepower
            // 
            this.Alg1stHorsepower.AutoSize = true;
            this.Alg1stHorsepower.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alg1stHorsepower.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.Alg1stHorsepower.Location = new System.Drawing.Point(371, 204);
            this.Alg1stHorsepower.Name = "Alg1stHorsepower";
            this.Alg1stHorsepower.Size = new System.Drawing.Size(40, 24);
            this.Alg1stHorsepower.TabIndex = 39;
            this.Alg1stHorsepower.Text = "123";
            // 
            // Alg1stLitres
            // 
            this.Alg1stLitres.AutoSize = true;
            this.Alg1stLitres.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alg1stLitres.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.Alg1stLitres.Location = new System.Drawing.Point(608, 204);
            this.Alg1stLitres.Name = "Alg1stLitres";
            this.Alg1stLitres.Size = new System.Drawing.Size(30, 24);
            this.Alg1stLitres.TabIndex = 40;
            this.Alg1stLitres.Text = "12";
            // 
            // Alg1stFuelType
            // 
            this.Alg1stFuelType.AutoSize = true;
            this.Alg1stFuelType.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alg1stFuelType.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.Alg1stFuelType.Location = new System.Drawing.Point(432, 229);
            this.Alg1stFuelType.Name = "Alg1stFuelType";
            this.Alg1stFuelType.Size = new System.Drawing.Size(157, 24);
            this.Alg1stFuelType.TabIndex = 41;
            this.Alg1stFuelType.Text = "Random fuel type";
            // 
            // Alg1stTransmission
            // 
            this.Alg1stTransmission.AutoSize = true;
            this.Alg1stTransmission.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alg1stTransmission.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.Alg1stTransmission.Location = new System.Drawing.Point(448, 253);
            this.Alg1stTransmission.Name = "Alg1stTransmission";
            this.Alg1stTransmission.Size = new System.Drawing.Size(188, 24);
            this.Alg1stTransmission.TabIndex = 42;
            this.Alg1stTransmission.Text = "continuous automatic";
            // 
            // Alg2ndTransmission
            // 
            this.Alg2ndTransmission.AutoSize = true;
            this.Alg2ndTransmission.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alg2ndTransmission.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.Alg2ndTransmission.Location = new System.Drawing.Point(448, 435);
            this.Alg2ndTransmission.Name = "Alg2ndTransmission";
            this.Alg2ndTransmission.Size = new System.Drawing.Size(188, 24);
            this.Alg2ndTransmission.TabIndex = 52;
            this.Alg2ndTransmission.Text = "continuous automatic";
            // 
            // Alg2ndFuelType
            // 
            this.Alg2ndFuelType.AutoSize = true;
            this.Alg2ndFuelType.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alg2ndFuelType.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.Alg2ndFuelType.Location = new System.Drawing.Point(432, 411);
            this.Alg2ndFuelType.Name = "Alg2ndFuelType";
            this.Alg2ndFuelType.Size = new System.Drawing.Size(157, 24);
            this.Alg2ndFuelType.TabIndex = 51;
            this.Alg2ndFuelType.Text = "Random fuel type";
            // 
            // Alg2ndLitres
            // 
            this.Alg2ndLitres.AutoSize = true;
            this.Alg2ndLitres.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alg2ndLitres.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.Alg2ndLitres.Location = new System.Drawing.Point(608, 386);
            this.Alg2ndLitres.Name = "Alg2ndLitres";
            this.Alg2ndLitres.Size = new System.Drawing.Size(30, 24);
            this.Alg2ndLitres.TabIndex = 50;
            this.Alg2ndLitres.Text = "12";
            // 
            // Alg2ndHorsepower
            // 
            this.Alg2ndHorsepower.AutoSize = true;
            this.Alg2ndHorsepower.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alg2ndHorsepower.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.Alg2ndHorsepower.Location = new System.Drawing.Point(371, 386);
            this.Alg2ndHorsepower.Name = "Alg2ndHorsepower";
            this.Alg2ndHorsepower.Size = new System.Drawing.Size(40, 24);
            this.Alg2ndHorsepower.TabIndex = 49;
            this.Alg2ndHorsepower.Text = "123";
            // 
            // Alg2ndPrice
            // 
            this.Alg2ndPrice.AutoSize = true;
            this.Alg2ndPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alg2ndPrice.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.Alg2ndPrice.Location = new System.Drawing.Point(393, 363);
            this.Alg2ndPrice.Name = "Alg2ndPrice";
            this.Alg2ndPrice.Size = new System.Drawing.Size(221, 24);
            this.Alg2ndPrice.TabIndex = 48;
            this.Alg2ndPrice.Text = "Here goes price in kunas";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(324, 435);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(127, 24);
            this.label13.TabIndex = 47;
            this.label13.Text = "Transmission:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(445, 386);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(157, 24);
            this.label14.TabIndex = 46;
            this.label14.Text = "Litres per 100 km:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(324, 411);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(93, 24);
            this.label15.TabIndex = 45;
            this.label15.Text = "Fuel type:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(324, 387);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(41, 24);
            this.label16.TabIndex = 44;
            this.label16.Text = "HP:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(324, 363);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(58, 24);
            this.label17.TabIndex = 43;
            this.label17.Text = "Price:";
            // 
            // Alg3rdTransmission
            // 
            this.Alg3rdTransmission.AutoSize = true;
            this.Alg3rdTransmission.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alg3rdTransmission.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.Alg3rdTransmission.Location = new System.Drawing.Point(457, 595);
            this.Alg3rdTransmission.Name = "Alg3rdTransmission";
            this.Alg3rdTransmission.Size = new System.Drawing.Size(188, 24);
            this.Alg3rdTransmission.TabIndex = 62;
            this.Alg3rdTransmission.Text = "continuous automatic";
            // 
            // Alg3rdFuelType
            // 
            this.Alg3rdFuelType.AutoSize = true;
            this.Alg3rdFuelType.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alg3rdFuelType.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.Alg3rdFuelType.Location = new System.Drawing.Point(441, 571);
            this.Alg3rdFuelType.Name = "Alg3rdFuelType";
            this.Alg3rdFuelType.Size = new System.Drawing.Size(157, 24);
            this.Alg3rdFuelType.TabIndex = 61;
            this.Alg3rdFuelType.Text = "Random fuel type";
            // 
            // Alg3rdLitres
            // 
            this.Alg3rdLitres.AutoSize = true;
            this.Alg3rdLitres.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alg3rdLitres.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.Alg3rdLitres.Location = new System.Drawing.Point(617, 546);
            this.Alg3rdLitres.Name = "Alg3rdLitres";
            this.Alg3rdLitres.Size = new System.Drawing.Size(30, 24);
            this.Alg3rdLitres.TabIndex = 60;
            this.Alg3rdLitres.Text = "12";
            // 
            // Alg3rdHorsepower
            // 
            this.Alg3rdHorsepower.AutoSize = true;
            this.Alg3rdHorsepower.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alg3rdHorsepower.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.Alg3rdHorsepower.Location = new System.Drawing.Point(380, 546);
            this.Alg3rdHorsepower.Name = "Alg3rdHorsepower";
            this.Alg3rdHorsepower.Size = new System.Drawing.Size(40, 24);
            this.Alg3rdHorsepower.TabIndex = 59;
            this.Alg3rdHorsepower.Text = "123";
            // 
            // Alg3rdPrice
            // 
            this.Alg3rdPrice.AutoSize = true;
            this.Alg3rdPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alg3rdPrice.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.Alg3rdPrice.Location = new System.Drawing.Point(402, 523);
            this.Alg3rdPrice.Name = "Alg3rdPrice";
            this.Alg3rdPrice.Size = new System.Drawing.Size(221, 24);
            this.Alg3rdPrice.TabIndex = 58;
            this.Alg3rdPrice.Text = "Here goes price in kunas";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(333, 595);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(127, 24);
            this.label23.TabIndex = 57;
            this.label23.Text = "Transmission:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(454, 546);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(157, 24);
            this.label24.TabIndex = 56;
            this.label24.Text = "Litres per 100 km:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(333, 571);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(93, 24);
            this.label25.TabIndex = 55;
            this.label25.Text = "Fuel type:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(333, 547);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(41, 24);
            this.label26.TabIndex = 54;
            this.label26.Text = "HP:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(333, 523);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(58, 24);
            this.label27.TabIndex = 53;
            this.label27.Text = "Price:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(712, 64);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(575, 72);
            this.label8.TabIndex = 63;
            this.label8.Text = "On the other hand, ML algorithm (which is not sharpest tool in the\r\nshed yet) als" +
    "o tried to conclude based on the data you gave us, and\r\nit concluded that the be" +
    "st cars for you are:";
            // 
            // ML1stTransmission
            // 
            this.ML1stTransmission.AutoSize = true;
            this.ML1stTransmission.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ML1stTransmission.ForeColor = System.Drawing.Color.SeaGreen;
            this.ML1stTransmission.Location = new System.Drawing.Point(1125, 277);
            this.ML1stTransmission.Name = "ML1stTransmission";
            this.ML1stTransmission.Size = new System.Drawing.Size(188, 24);
            this.ML1stTransmission.TabIndex = 76;
            this.ML1stTransmission.Text = "continuous automatic";
            // 
            // ML1stFuelType
            // 
            this.ML1stFuelType.AutoSize = true;
            this.ML1stFuelType.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ML1stFuelType.ForeColor = System.Drawing.Color.SeaGreen;
            this.ML1stFuelType.Location = new System.Drawing.Point(1109, 253);
            this.ML1stFuelType.Name = "ML1stFuelType";
            this.ML1stFuelType.Size = new System.Drawing.Size(157, 24);
            this.ML1stFuelType.TabIndex = 75;
            this.ML1stFuelType.Text = "Random fuel type";
            // 
            // ML1stLitres
            // 
            this.ML1stLitres.AutoSize = true;
            this.ML1stLitres.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ML1stLitres.ForeColor = System.Drawing.Color.SeaGreen;
            this.ML1stLitres.Location = new System.Drawing.Point(1285, 228);
            this.ML1stLitres.Name = "ML1stLitres";
            this.ML1stLitres.Size = new System.Drawing.Size(30, 24);
            this.ML1stLitres.TabIndex = 74;
            this.ML1stLitres.Text = "12";
            // 
            // ML1stHorsepower
            // 
            this.ML1stHorsepower.AutoSize = true;
            this.ML1stHorsepower.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ML1stHorsepower.ForeColor = System.Drawing.Color.SeaGreen;
            this.ML1stHorsepower.Location = new System.Drawing.Point(1048, 228);
            this.ML1stHorsepower.Name = "ML1stHorsepower";
            this.ML1stHorsepower.Size = new System.Drawing.Size(40, 24);
            this.ML1stHorsepower.TabIndex = 73;
            this.ML1stHorsepower.Text = "123";
            // 
            // ML1stCarPrice
            // 
            this.ML1stCarPrice.AutoSize = true;
            this.ML1stCarPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ML1stCarPrice.ForeColor = System.Drawing.Color.SeaGreen;
            this.ML1stCarPrice.Location = new System.Drawing.Point(1070, 205);
            this.ML1stCarPrice.Name = "ML1stCarPrice";
            this.ML1stCarPrice.Size = new System.Drawing.Size(221, 24);
            this.ML1stCarPrice.TabIndex = 72;
            this.ML1stCarPrice.Text = "Here goes price in kunas";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(1001, 277);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(127, 24);
            this.label19.TabIndex = 71;
            this.label19.Text = "Transmission:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(1122, 228);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(157, 24);
            this.label20.TabIndex = 70;
            this.label20.Text = "Litres per 100 km:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(1001, 253);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(93, 24);
            this.label21.TabIndex = 69;
            this.label21.Text = "Fuel type:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(1001, 229);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(41, 24);
            this.label22.TabIndex = 68;
            this.label22.Text = "HP:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(1001, 205);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(58, 24);
            this.label28.TabIndex = 67;
            this.label28.Text = "Price:";
            // 
            // ML1stCarName
            // 
            this.ML1stCarName.AutoSize = true;
            this.ML1stCarName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ML1stCarName.Location = new System.Drawing.Point(758, 167);
            this.ML1stCarName.Name = "ML1stCarName";
            this.ML1stCarName.Size = new System.Drawing.Size(120, 24);
            this.ML1stCarName.TabIndex = 66;
            this.ML1stCarName.Text = "1st Car name";
            // 
            // ML1stNumber
            // 
            this.ML1stNumber.AutoSize = true;
            this.ML1stNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ML1stNumber.Location = new System.Drawing.Point(704, 228);
            this.ML1stNumber.Name = "ML1stNumber";
            this.ML1stNumber.Size = new System.Drawing.Size(32, 29);
            this.ML1stNumber.TabIndex = 65;
            this.ML1stNumber.Text = "1.";
            // 
            // pictureBox1stML
            // 
            this.pictureBox1stML.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1stML.Image")));
            this.pictureBox1stML.Location = new System.Drawing.Point(762, 194);
            this.pictureBox1stML.Name = "pictureBox1stML";
            this.pictureBox1stML.Size = new System.Drawing.Size(233, 111);
            this.pictureBox1stML.TabIndex = 64;
            this.pictureBox1stML.TabStop = false;
            // 
            // ML2ndTransmission
            // 
            this.ML2ndTransmission.AutoSize = true;
            this.ML2ndTransmission.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ML2ndTransmission.ForeColor = System.Drawing.Color.SeaGreen;
            this.ML2ndTransmission.Location = new System.Drawing.Point(1125, 436);
            this.ML2ndTransmission.Name = "ML2ndTransmission";
            this.ML2ndTransmission.Size = new System.Drawing.Size(188, 24);
            this.ML2ndTransmission.TabIndex = 89;
            this.ML2ndTransmission.Text = "continuous automatic";
            // 
            // ML2ndFuelType
            // 
            this.ML2ndFuelType.AutoSize = true;
            this.ML2ndFuelType.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ML2ndFuelType.ForeColor = System.Drawing.Color.SeaGreen;
            this.ML2ndFuelType.Location = new System.Drawing.Point(1109, 412);
            this.ML2ndFuelType.Name = "ML2ndFuelType";
            this.ML2ndFuelType.Size = new System.Drawing.Size(157, 24);
            this.ML2ndFuelType.TabIndex = 88;
            this.ML2ndFuelType.Text = "Random fuel type";
            // 
            // ML2ndLitres
            // 
            this.ML2ndLitres.AutoSize = true;
            this.ML2ndLitres.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ML2ndLitres.ForeColor = System.Drawing.Color.SeaGreen;
            this.ML2ndLitres.Location = new System.Drawing.Point(1285, 387);
            this.ML2ndLitres.Name = "ML2ndLitres";
            this.ML2ndLitres.Size = new System.Drawing.Size(30, 24);
            this.ML2ndLitres.TabIndex = 87;
            this.ML2ndLitres.Text = "12";
            // 
            // ML2ndHorsepower
            // 
            this.ML2ndHorsepower.AutoSize = true;
            this.ML2ndHorsepower.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ML2ndHorsepower.ForeColor = System.Drawing.Color.SeaGreen;
            this.ML2ndHorsepower.Location = new System.Drawing.Point(1048, 387);
            this.ML2ndHorsepower.Name = "ML2ndHorsepower";
            this.ML2ndHorsepower.Size = new System.Drawing.Size(40, 24);
            this.ML2ndHorsepower.TabIndex = 86;
            this.ML2ndHorsepower.Text = "123";
            // 
            // ML2ndPrice
            // 
            this.ML2ndPrice.AutoSize = true;
            this.ML2ndPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ML2ndPrice.ForeColor = System.Drawing.Color.SeaGreen;
            this.ML2ndPrice.Location = new System.Drawing.Point(1070, 364);
            this.ML2ndPrice.Name = "ML2ndPrice";
            this.ML2ndPrice.Size = new System.Drawing.Size(221, 24);
            this.ML2ndPrice.TabIndex = 85;
            this.ML2ndPrice.Text = "Here goes price in kunas";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(1001, 436);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(127, 24);
            this.label36.TabIndex = 84;
            this.label36.Text = "Transmission:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(1122, 387);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(157, 24);
            this.label37.TabIndex = 83;
            this.label37.Text = "Litres per 100 km:";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(1001, 412);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(93, 24);
            this.label38.TabIndex = 82;
            this.label38.Text = "Fuel type:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(1001, 388);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(41, 24);
            this.label39.TabIndex = 81;
            this.label39.Text = "HP:";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(1001, 364);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(58, 24);
            this.label40.TabIndex = 80;
            this.label40.Text = "Price:";
            // 
            // ML2ndCarName
            // 
            this.ML2ndCarName.AutoSize = true;
            this.ML2ndCarName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ML2ndCarName.Location = new System.Drawing.Point(758, 326);
            this.ML2ndCarName.Name = "ML2ndCarName";
            this.ML2ndCarName.Size = new System.Drawing.Size(129, 24);
            this.ML2ndCarName.TabIndex = 79;
            this.ML2ndCarName.Text = "2nd Car name";
            // 
            // ML2ndNumber
            // 
            this.ML2ndNumber.AutoSize = true;
            this.ML2ndNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ML2ndNumber.Location = new System.Drawing.Point(704, 387);
            this.ML2ndNumber.Name = "ML2ndNumber";
            this.ML2ndNumber.Size = new System.Drawing.Size(32, 29);
            this.ML2ndNumber.TabIndex = 78;
            this.ML2ndNumber.Text = "2.";
            // 
            // pictureBox2ndML
            // 
            this.pictureBox2ndML.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2ndML.Image")));
            this.pictureBox2ndML.Location = new System.Drawing.Point(762, 353);
            this.pictureBox2ndML.Name = "pictureBox2ndML";
            this.pictureBox2ndML.Size = new System.Drawing.Size(233, 111);
            this.pictureBox2ndML.TabIndex = 77;
            this.pictureBox2ndML.TabStop = false;
            // 
            // ML3rdTransmission
            // 
            this.ML3rdTransmission.AutoSize = true;
            this.ML3rdTransmission.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ML3rdTransmission.ForeColor = System.Drawing.Color.SeaGreen;
            this.ML3rdTransmission.Location = new System.Drawing.Point(1125, 591);
            this.ML3rdTransmission.Name = "ML3rdTransmission";
            this.ML3rdTransmission.Size = new System.Drawing.Size(188, 24);
            this.ML3rdTransmission.TabIndex = 102;
            this.ML3rdTransmission.Text = "continuous automatic";
            // 
            // ML3rdFuelType
            // 
            this.ML3rdFuelType.AutoSize = true;
            this.ML3rdFuelType.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ML3rdFuelType.ForeColor = System.Drawing.Color.SeaGreen;
            this.ML3rdFuelType.Location = new System.Drawing.Point(1109, 567);
            this.ML3rdFuelType.Name = "ML3rdFuelType";
            this.ML3rdFuelType.Size = new System.Drawing.Size(157, 24);
            this.ML3rdFuelType.TabIndex = 101;
            this.ML3rdFuelType.Text = "Random fuel type";
            // 
            // ML3rdLitres
            // 
            this.ML3rdLitres.AutoSize = true;
            this.ML3rdLitres.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ML3rdLitres.ForeColor = System.Drawing.Color.SeaGreen;
            this.ML3rdLitres.Location = new System.Drawing.Point(1285, 542);
            this.ML3rdLitres.Name = "ML3rdLitres";
            this.ML3rdLitres.Size = new System.Drawing.Size(30, 24);
            this.ML3rdLitres.TabIndex = 100;
            this.ML3rdLitres.Text = "12";
            // 
            // ML3rdHorsepower
            // 
            this.ML3rdHorsepower.AutoSize = true;
            this.ML3rdHorsepower.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ML3rdHorsepower.ForeColor = System.Drawing.Color.SeaGreen;
            this.ML3rdHorsepower.Location = new System.Drawing.Point(1048, 542);
            this.ML3rdHorsepower.Name = "ML3rdHorsepower";
            this.ML3rdHorsepower.Size = new System.Drawing.Size(40, 24);
            this.ML3rdHorsepower.TabIndex = 99;
            this.ML3rdHorsepower.Text = "123";
            // 
            // ML3rdPrice
            // 
            this.ML3rdPrice.AutoSize = true;
            this.ML3rdPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ML3rdPrice.ForeColor = System.Drawing.Color.SeaGreen;
            this.ML3rdPrice.Location = new System.Drawing.Point(1070, 519);
            this.ML3rdPrice.Name = "ML3rdPrice";
            this.ML3rdPrice.Size = new System.Drawing.Size(221, 24);
            this.ML3rdPrice.TabIndex = 98;
            this.ML3rdPrice.Text = "Here goes price in kunas";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(1001, 591);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(127, 24);
            this.label48.TabIndex = 97;
            this.label48.Text = "Transmission:";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(1122, 542);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(157, 24);
            this.label49.TabIndex = 96;
            this.label49.Text = "Litres per 100 km:";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(1001, 567);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(93, 24);
            this.label50.TabIndex = 95;
            this.label50.Text = "Fuel type:";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(1001, 543);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(41, 24);
            this.label51.TabIndex = 94;
            this.label51.Text = "HP:";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(1001, 519);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(58, 24);
            this.label52.TabIndex = 93;
            this.label52.Text = "Price:";
            // 
            // ML3rdCarName
            // 
            this.ML3rdCarName.AutoSize = true;
            this.ML3rdCarName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ML3rdCarName.Location = new System.Drawing.Point(758, 481);
            this.ML3rdCarName.Name = "ML3rdCarName";
            this.ML3rdCarName.Size = new System.Drawing.Size(124, 24);
            this.ML3rdCarName.TabIndex = 92;
            this.ML3rdCarName.Text = "3rd Car name";
            // 
            // ML3rdNumber
            // 
            this.ML3rdNumber.AutoSize = true;
            this.ML3rdNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ML3rdNumber.Location = new System.Drawing.Point(704, 542);
            this.ML3rdNumber.Name = "ML3rdNumber";
            this.ML3rdNumber.Size = new System.Drawing.Size(32, 29);
            this.ML3rdNumber.TabIndex = 91;
            this.ML3rdNumber.Text = "3.";
            // 
            // pictureBox3rdML
            // 
            this.pictureBox3rdML.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3rdML.Image")));
            this.pictureBox3rdML.Location = new System.Drawing.Point(762, 508);
            this.pictureBox3rdML.Name = "pictureBox3rdML";
            this.pictureBox3rdML.Size = new System.Drawing.Size(233, 111);
            this.pictureBox3rdML.TabIndex = 90;
            this.pictureBox3rdML.TabStop = false;
            // 
            // lblFinishing
            // 
            this.lblFinishing.AutoSize = true;
            this.lblFinishing.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinishing.Location = new System.Drawing.Point(42, 652);
            this.lblFinishing.Name = "lblFinishing";
            this.lblFinishing.Size = new System.Drawing.Size(1240, 48);
            this.lblFinishing.TabIndex = 103;
            this.lblFinishing.Text = "Hopefully this recommender system gave you useful car recommendations based on yo" +
    "ur preferences, also fingers crossed that ML \r\nalgorithm gave some good ideas to" +
    "o!";
            // 
            // btnAgain
            // 
            this.btnAgain.BackColor = System.Drawing.Color.ForestGreen;
            this.btnAgain.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAgain.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgain.ForeColor = System.Drawing.Color.GhostWhite;
            this.btnAgain.Location = new System.Drawing.Point(1071, 690);
            this.btnAgain.Name = "btnAgain";
            this.btnAgain.Size = new System.Drawing.Size(91, 34);
            this.btnAgain.TabIndex = 104;
            this.btnAgain.Text = "Try again";
            this.btnAgain.UseVisualStyleBackColor = false;
            this.btnAgain.Click += new System.EventHandler(this.btnAgain_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.OrangeRed;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.Color.GhostWhite;
            this.btnClose.Location = new System.Drawing.Point(1173, 690);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(152, 34);
            this.btnClose.TabIndex = 105;
            this.btnClose.Text = "Close application";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // Results
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1360, 737);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnAgain);
            this.Controls.Add(this.lblFinishing);
            this.Controls.Add(this.ML3rdTransmission);
            this.Controls.Add(this.ML3rdFuelType);
            this.Controls.Add(this.ML3rdLitres);
            this.Controls.Add(this.ML3rdHorsepower);
            this.Controls.Add(this.ML3rdPrice);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.label50);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.label52);
            this.Controls.Add(this.ML3rdCarName);
            this.Controls.Add(this.ML3rdNumber);
            this.Controls.Add(this.pictureBox3rdML);
            this.Controls.Add(this.ML2ndTransmission);
            this.Controls.Add(this.ML2ndFuelType);
            this.Controls.Add(this.ML2ndLitres);
            this.Controls.Add(this.ML2ndHorsepower);
            this.Controls.Add(this.ML2ndPrice);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.ML2ndCarName);
            this.Controls.Add(this.ML2ndNumber);
            this.Controls.Add(this.pictureBox2ndML);
            this.Controls.Add(this.ML1stTransmission);
            this.Controls.Add(this.ML1stFuelType);
            this.Controls.Add(this.ML1stLitres);
            this.Controls.Add(this.ML1stHorsepower);
            this.Controls.Add(this.ML1stCarPrice);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.ML1stCarName);
            this.Controls.Add(this.ML1stNumber);
            this.Controls.Add(this.pictureBox1stML);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.Alg3rdTransmission);
            this.Controls.Add(this.Alg3rdFuelType);
            this.Controls.Add(this.Alg3rdLitres);
            this.Controls.Add(this.Alg3rdHorsepower);
            this.Controls.Add(this.Alg3rdPrice);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.Alg2ndTransmission);
            this.Controls.Add(this.Alg2ndFuelType);
            this.Controls.Add(this.Alg2ndLitres);
            this.Controls.Add(this.Alg2ndHorsepower);
            this.Controls.Add(this.Alg2ndPrice);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.Alg1stTransmission);
            this.Controls.Add(this.Alg1stFuelType);
            this.Controls.Add(this.Alg1stLitres);
            this.Controls.Add(this.Alg1stHorsepower);
            this.Controls.Add(this.Alg1stPrice);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBoxVerticalLine);
            this.Controls.Add(this.Alg3rdCarName);
            this.Controls.Add(this.label3rdAlg);
            this.Controls.Add(this.pictureBox3rdAlg);
            this.Controls.Add(this.Alg2ndCarName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox2ndAlg);
            this.Controls.Add(this.Alg1stCarName);
            this.Controls.Add(this.label1stAlg);
            this.Controls.Add(this.pictureBox1stAlg);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1376, 776);
            this.MinimumSize = new System.Drawing.Size(1376, 776);
            this.Name = "Results";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Result page";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1stAlg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2ndAlg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3rdAlg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxVerticalLine)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1stML)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2ndML)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3rdML)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1stAlg;
        private System.Windows.Forms.Label label1stAlg;
        private System.Windows.Forms.Label Alg1stCarName;
        private System.Windows.Forms.Label Alg2ndCarName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox2ndAlg;
        private System.Windows.Forms.Label Alg3rdCarName;
        private System.Windows.Forms.Label label3rdAlg;
        private System.Windows.Forms.PictureBox pictureBox3rdAlg;
        private System.Windows.Forms.PictureBox pictureBoxVerticalLine;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label Alg1stPrice;
        private System.Windows.Forms.Label Alg1stHorsepower;
        private System.Windows.Forms.Label Alg1stLitres;
        private System.Windows.Forms.Label Alg1stFuelType;
        private System.Windows.Forms.Label Alg1stTransmission;
        private System.Windows.Forms.Label Alg2ndTransmission;
        private System.Windows.Forms.Label Alg2ndFuelType;
        private System.Windows.Forms.Label Alg2ndLitres;
        private System.Windows.Forms.Label Alg2ndHorsepower;
        private System.Windows.Forms.Label Alg2ndPrice;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label Alg3rdTransmission;
        private System.Windows.Forms.Label Alg3rdFuelType;
        private System.Windows.Forms.Label Alg3rdLitres;
        private System.Windows.Forms.Label Alg3rdHorsepower;
        private System.Windows.Forms.Label Alg3rdPrice;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label ML1stTransmission;
        private System.Windows.Forms.Label ML1stFuelType;
        private System.Windows.Forms.Label ML1stLitres;
        private System.Windows.Forms.Label ML1stHorsepower;
        private System.Windows.Forms.Label ML1stCarPrice;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label ML1stCarName;
        private System.Windows.Forms.Label ML1stNumber;
        private System.Windows.Forms.PictureBox pictureBox1stML;
        private System.Windows.Forms.Label ML2ndTransmission;
        private System.Windows.Forms.Label ML2ndFuelType;
        private System.Windows.Forms.Label ML2ndLitres;
        private System.Windows.Forms.Label ML2ndHorsepower;
        private System.Windows.Forms.Label ML2ndPrice;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label ML2ndCarName;
        private System.Windows.Forms.Label ML2ndNumber;
        private System.Windows.Forms.PictureBox pictureBox2ndML;
        private System.Windows.Forms.Label ML3rdTransmission;
        private System.Windows.Forms.Label ML3rdFuelType;
        private System.Windows.Forms.Label ML3rdLitres;
        private System.Windows.Forms.Label ML3rdHorsepower;
        private System.Windows.Forms.Label ML3rdPrice;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label ML3rdCarName;
        private System.Windows.Forms.Label ML3rdNumber;
        private System.Windows.Forms.PictureBox pictureBox3rdML;
        private System.Windows.Forms.Label lblFinishing;
        private System.Windows.Forms.Button btnAgain;
        private System.Windows.Forms.Button btnClose;
    }
}